// variables set by you, the user
var iframe = "classes.php";					// location of game
var finishframe = iframe;					// re-direct when game is over
var numtrials = 20;							// number of trials
//var trialtime = 25;							// number of seconds alloted per trial
var trialredtime = 3;						// triggers red warning for trial time (0 for no red-time)
var totalredtime = 3;						// triggers red warning for total time (0 for no red-time)
var numpracticetrials=5;					//number of practice trials
var practicetime=400;


